//: Coursera Test ITESM Semana 2.
// Benito Silva Cuevas

import UIKit

let two : Int = 2
let five : Int = 5

for i in 1...100{
    var numeroFive = i % five
    var numeroTwo = i % two
    if (i > 29 && i < 41) && (numeroFive == 0) && (numeroTwo == 0){
        print("\(i) Viva Swift!!!")
    }
    else
        if (numeroFive == 0){
            print("\(i) Bingo!!!")
            
        }
        else
            if (i%two == 0){
                print("\(i) Es número par")
            }
            else {
                print("\(i) Es número impar")
    }
}